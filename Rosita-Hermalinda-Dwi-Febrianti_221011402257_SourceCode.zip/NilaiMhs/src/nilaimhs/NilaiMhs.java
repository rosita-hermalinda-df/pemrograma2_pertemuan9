package nilaimhs;

import java.util.Scanner;

public class NilaiMhs {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Deklarasi variabel
        String nim, nama, grade;
        double uas, uts, rata, nih, nia;

        // Input data mahasiswa
        System.out.println("Masukkan Data Mahasiswa:");
        System.out.print("NIM: ");
        nim = input.next();
        input.nextLine(); // Membersihkan buffer setelah next()
        System.out.print("Nama: ");
        nama = input.nextLine();
        System.out.print("Nilai UTS: ");
        uts = input.nextDouble();
        System.out.print("Nilai UAS: ");
        uas = input.nextDouble();
        System.out.print("Nilai Nih: ");
        nih = input.nextDouble();
        System.out.print("Nilai Nia: ");
        nia = input.nextDouble();

        // Menghitung rata-rata
        rata = (uas + uts + nih + nia) / 4;

        // Menentukan grade berdasarkan rata-rata
        if (rata < 50)
            grade = "E";
        else if (rata < 60)
            grade = "D";
        else if (rata < 70)
            grade = "C";
        else if (rata < 80)
            grade = "B";
        else
            grade = "A";

        // Menampilkan hasil
        System.out.println("\n======================================================");
        System.out.printf("%-10s %-15s %-5s %-5s %-7s %-5s %-5s %-6s%n", 
                          "NIM", "Nama", "UTS", "UAS", "Rata2", "Nih", "Nia", "Grade");
        System.out.println("========================================================");
        System.out.printf("%-10s %-15s %-5.2f %-5.2f %-7.2f %-5.2f %-5.2f %-6s%n", 
                          nim, nama, uts, uas, rata, nih, nia, grade);
        System.out.println("========================================================");

        input.close(); // Menutup scanner untuk mencegah kebocoran memori
    }
}
