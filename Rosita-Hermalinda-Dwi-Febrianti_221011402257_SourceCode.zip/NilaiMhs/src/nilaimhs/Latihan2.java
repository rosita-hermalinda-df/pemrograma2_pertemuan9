/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nilaimhs;

import javax.swing.*;

/**
 *
 * @author Mega Global
 */
public class Latihan2 {
/**
 * @param args the command line arguments
 */
    public static void main(String[] args){
        //TODO code application logic here
        JFrame frame = new JFrame ("GUI Sederhana");
        JLabel label = new JLabel ("Hello Swing!");
        JButton button = new JButton ("Klik Saya");
        
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        
        label.setBounds(150, 130, 150, 50);
        button.setBounds(150, 170, 120, 70);
        
        frame.add(label);
        frame.add(button);
        frame.setVisible(true);
    }
}